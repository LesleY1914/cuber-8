
document.addEventListener('DOMContentLoaded', function () {
    const editButton = document.getElementById('editbtn');
    const canceButton = document.getElementById('cancelarbtn');
    const cerrarSesion = document.getElementById("btncerrarSesion");
    let isEditMode = false;

    editButton.addEventListener('click', function (e) {
        e.preventDefault();

        if (!isEditMode){

        document.querySelectorAll('.formControl').forEach(input => {
            input.removeAttribute('readonly');
        });

        editButton.textContent = 'Guardar';
        isEditMode = true;

    }else{

        document.querySelectorAll('.formControl').forEach(input =>{
            input.removeAttribute(true);
        });
        
        editButton.textContent = 'Editar';
        isEditMode = false;
        alert('Informacion guardada con exito');
    }



    });




    canceButton.addEventListener('click', function (e) {
        e.preventDefault();

        window.location.href = "/public/vistasAdmin/Usuarios.html";


    });

    cerrarSesion.addEventListener('click', function(e){
        e.preventDefault();
      
        alert('Seguro que quieres cerrar sesión?')
      
        window.location.href ="/Login.html";
        history.replaceState(null,"", "/Login.html");
      
        
      });



});






